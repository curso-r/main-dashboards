# htmlwidgets
#
# Reproduza o seguinte Shiny app:
# https://acursor.shinyapps.io/htmlwidgets-1/
#
# A base utilizada foi a cetesb, presente no material do curso.
# Você também pode acessar a base clicando no link abaixo:
# https://github.com/curso-r/livro-shiny/raw/master/exemplos/data/cetesb.rds

