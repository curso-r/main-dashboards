# Selecionando várias opções
# 
# (a) Reproduza o seguinte Shiny app: 
# https://cursodashboards.shinyapps.io/select-multiple/
#   
# (b) Troque o selectInput pelo checkboxGroupInput().
# 
# Para acessar a base utilizada, rode o código abaixo:

install.packages(nycflights13)
nycflights13::flights
