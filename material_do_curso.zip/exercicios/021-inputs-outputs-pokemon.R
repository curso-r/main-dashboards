# Explorando inputs
# 
# Utilizando a base de pokemon, faça um Shiny app que permite escolher
# um tipo (tipo_1) e uma geração e faça um gráfico de dispersão do ataque 
# vs defesa para os pokemon com essas características.