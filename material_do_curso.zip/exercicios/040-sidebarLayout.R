# Reconstrua os apps dos exercícios 3.1, 3.2 e 3.3, agora utilizando
# o sidebarLayout.