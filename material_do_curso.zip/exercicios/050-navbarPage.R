# navbarPage
# 
# Utilizando a base cetesb, faça um shiny app que tenha duas abas:
#
# - a primeira com uma série temporal da média diária do ozônio (O3),
# permitindo a escolha do intervalo de dias em que o gráfico é gerado
#
# - a segunda com a série temporal da média diária do último mês da base 
# permitindo a escolha do poluente.