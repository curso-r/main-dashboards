# UI reativa
# 
# Construa um shiny app que possua um filtro de
# pokemon que dependa de um filtro de tipo 1 e um filtro de tipo 2.
#
# Como output, faça um gráfico de dispersão do ataque vs defesa dos
# pokemon selecionados. 

