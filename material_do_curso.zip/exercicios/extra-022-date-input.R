# Date input
# 
# Reproduza o seguinte Shiny app: 
# https://cursodashboards.shinyapps.io/select-date/
#   
# Para acessar a base utilizada, rode o código abaixo:

install.packages(nycflights13)
nycflights13::flights
