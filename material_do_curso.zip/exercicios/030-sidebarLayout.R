# Reconstrua os apps dos exercícios 2.0, 2.1 e 2.2, agora utilizando
# o sidebarLayout.